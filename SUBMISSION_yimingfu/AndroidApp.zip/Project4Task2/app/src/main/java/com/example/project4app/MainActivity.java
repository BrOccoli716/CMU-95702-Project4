package com.example.project4app;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnPlayer = findViewById(R.id.btnPlayer);
        Button btnTeam = findViewById(R.id.btnTeam);

        // 跳转 Player 页面
        btnPlayer.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PlayerActivity.class);
            startActivity(intent);
        });

        // 跳转 Team 页面
        btnTeam.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, TeamActivity.class);
            startActivity(intent);
        });
    }
}