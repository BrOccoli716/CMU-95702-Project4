package com.example.project4app;

public class Player {
    int id;
    String firstName, lastName;
    String position, jerseyNumber;
    String height, weight;
    String college, country;
    int draftYear, draftRound, draftNumber;
    Team team;
    String imageUrl;

    public Player(int id, String firstName, String lastName, String position, String jerseyNumber, String height, String weight, String college, String country, int draftYear, int draftRound, int draftNumber, Team team, String imageUrl) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.position = position;
        this.jerseyNumber = jerseyNumber;
        this.height = height;
        this.weight = weight;
        this.college = college;
        this.country = country;
        this.draftYear = draftYear;
        this.draftRound = draftRound;
        this.draftNumber = draftNumber;
        this.team = team;
        this.imageUrl = imageUrl;
    }
}
