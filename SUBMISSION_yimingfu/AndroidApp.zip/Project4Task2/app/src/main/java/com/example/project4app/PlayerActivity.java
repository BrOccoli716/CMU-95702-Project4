package com.example.project4app;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class PlayerActivity extends AppCompatActivity {

    private static final int PAGE_SIZE = 10;

    RecyclerView recyclerView;
    PlayerAdapter adapter;

    List<Player> allPlayers = new ArrayList<>();
    List<Player> currentPagePlayers = new ArrayList<>();

    int currentPage = 0;
    int totalPages = 0;

    Button btnPrev, btnNext, btnSearch, btnBack;
    TextView tvPage, tvNoResult;
    EditText inputPlayerFirstName, inputPlayerLastName;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        recyclerView = findViewById(R.id.playerRecycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new PlayerAdapter(currentPagePlayers);
        recyclerView.setAdapter(adapter);

        btnPrev = findViewById(R.id.btnPrev);
        btnNext = findViewById(R.id.btnNext);
        btnSearch = findViewById(R.id.btnSearch);
        btnBack = findViewById(R.id.btnBack);
        inputPlayerFirstName = findViewById(R.id.inputPlayerFirstName);
        inputPlayerLastName = findViewById(R.id.inputPlayerLastName);
        tvPage = findViewById(R.id.tvPage);
        tvNoResult = findViewById(R.id.tvNoResult);
        progressBar = findViewById(R.id.progressBar);

        btnBack.setOnClickListener(v -> finish());

        btnSearch.setOnClickListener(v -> {
            currentPage = 0;
            String firstName = inputPlayerFirstName.getText().toString().trim().toLowerCase();
            String lastName = inputPlayerLastName.getText().toString().trim().toLowerCase();
            String urlString = buildUrl(firstName, lastName);
            System.out.println("Server URL: " + urlString);
            fetchPlayers(urlString);
        });

        btnPrev.setOnClickListener(v -> {
            if (currentPage > 0) {
                showPage(currentPage - 1);
            } else {
                Toast.makeText(this, "Already first page", Toast.LENGTH_SHORT).show();
            }
        });

        btnNext.setOnClickListener(v -> {
            if (currentPage < totalPages - 1) {
                showPage(currentPage + 1);
            } else {
                Toast.makeText(this, "Already last page", Toast.LENGTH_SHORT).show();
            }
        });

        loadPlayers("");
    }

    private void showLoading() {
        runOnUiThread(() -> progressBar.setVisibility(View.VISIBLE));
    }

    private void hideLoading() {
        runOnUiThread(() -> progressBar.setVisibility(View.GONE));
    }

    private String buildUrl(String firstName, String lastName) {
        String urlString = "https://crispy-chainsaw-7qj54556j9wfxrv9-8080.app.github.dev/api/player";
        if ((!firstName.isEmpty()) && (!lastName.isEmpty())) {
            urlString = "%s?first_name=%s&last_name=%s".formatted(urlString, firstName, lastName);
        } else if ((firstName.isEmpty()) && (!lastName.isEmpty())) {
            urlString = "%s?last_name=%s".formatted(urlString, lastName);
        } else if ((!firstName.isEmpty()) && (lastName.isEmpty())) {
            urlString = "%s?first_name=%s".formatted(urlString, firstName);
        }
        return urlString;
    }

    private void fetchPlayers(String url) {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)   // 连接服务器超时
                .readTimeout(15, TimeUnit.SECONDS)      // 读取响应超时
                .writeTimeout(15, TimeUnit.SECONDS)     // 写入请求超时
                .build();

        Request request = new Request.Builder()
                .url(url)
                .addHeader("Accept", "application/json")
                .addHeader("User-Agent", "Android")
                .build();

        runOnUiThread(this::showLoading);

        System.out.println("Start Requesting");

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                System.out.println("Call Failure!");
                e.printStackTrace();
                runOnUiThread(() -> {
                    hideLoading();
                    new AlertDialog.Builder(PlayerActivity.this)
                            .setTitle("Error")
                            .setMessage("Request Failed!")
                            .setPositiveButton("OK", null)
                            .setCancelable(true)
                            .show();
                    showPage(0);
                    adapter.updateData(allPlayers);
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                int httpStatus = response.code();
                String body = response.body().string();
                Log.d("BODY", body);
                Gson gson = new Gson();
                JsonObject root;
                try {
                    root = gson.fromJson(body, JsonObject.class);
                } catch (JsonSyntaxException e) {
                    System.out.println("Error in JSON response!");
                    runOnUiThread(() -> {
                        hideLoading();
                        new AlertDialog.Builder(PlayerActivity.this)
                                .setTitle("Error")
                                .setMessage("Server Response Error!")
                                .setPositiveButton("OK", null)
                                .setCancelable(true)
                                .show();
                    });
                    return;
                }

                if (httpStatus != 200) {
                    String msg = root.has("error")
                            ? root.get("error").getAsString()
                            : "Server error: " + httpStatus;
                    System.out.println(msg);
                    runOnUiThread(() -> {
                        hideLoading();
                        runOnUiThread(() -> {
                            new AlertDialog.Builder(PlayerActivity.this)
                                    .setTitle("Error")
                                    .setMessage(msg)
                                    .setPositiveButton("OK", null)
                                    .setCancelable(true)
                                    .show();
                        });
                    });
                    return;
                }
                JsonArray dataArray = root.getAsJsonArray("data");
                Log.d("PLAYER_JSON", dataArray.toString());
                // TODO：解析 JSON → List<Player>
                // List<Player> players = loadPlayers("");  // Only for TEST
                allPlayers = gson.fromJson(
                        dataArray,
                        new TypeToken<List<Player>>(){}.getType()
                );
                totalPages = (allPlayers.size() + PAGE_SIZE - 1) / PAGE_SIZE;
                runOnUiThread(() -> {
                    hideLoading();
                    adapter.updateData(allPlayers);
                    showPage(0);
                    Log.d("currentPagePlayers", currentPagePlayers.toString());
                });
            }
        });
    }

    // NOTE: This method is only used for initializing now (default page)
    private List<Player> loadPlayers(String json) {
        // Fake Data (for TEST)
//        json = "["
//                + "{\"id\":1,\"firstName\":\"Stephen\",\"lastName\":\"Curry\",\"teamName\":\"GSW\",\"position\":\"G\",\"height\":\"6'2\",\"weight\":\"185\",\"imageUrl\":\"https://cdn.nba.com/headshots/nba/latest/1040x760/2544.png\"},"
//                + "{\"id\":2,\"firstName\":\"LeBron\",\"lastName\":\"James\",\"teamName\":\"LAL\",\"position\":\"F\",\"height\":\"6'9\",\"weight\":\"250\",\"imageUrl\":\"https://cdn.nba.com/headshots/nba/latest/1040x760/2544.png\"},"
//                + "{\"id\":3,\"firstName\":\"Kevin\",\"lastName\":\"Durant\",\"teamName\":\"HOU\",\"position\":\"F\",\"height\":\"6'10\",\"weight\":\"240\",\"imageUrl\":\"https://cdn.nba.com/headshots/nba/latest/1040x760/2544.png\"}"
//                + "]";
        if (json.isEmpty()) {
            return null;
        }

        try {
            Type listType = new TypeToken<List<Player>>(){}.getType();
            allPlayers = new Gson().fromJson(json, listType);
            // Below only for testing
//            for (Player p : allPlayers) {
//                String name = p.firstName.toLowerCase() + "_" + p.lastName.toLowerCase();
//                // String team = p.teamName.toLowerCase();  // Used for TEST
//                String team = p.team.abbreviation.toLowerCase();
//                if (team.isEmpty()) {
//                    team = "NAN";
//                }
//                String key = name.replace(" ", "_") + "_" + team;
//                p.imageUrl = imageMap.get(key);
//                if (p.imageUrl == null) {
//                    name = p.lastName.toLowerCase() + "_" + p.firstName.toLowerCase();
//                    key = name.replace(" ", "_") + "_" + team;
//                    p.imageUrl = imageMap.get(key);
//                }
//                System.out.println(key + " " + p.imageUrl);
//            }
        } catch (Exception e) {
            System.out.println("Error in JSON response");
            System.out.println(e.getMessage());
        }

        totalPages = (allPlayers.size() + PAGE_SIZE - 1) / PAGE_SIZE;

        runOnUiThread(() -> {
            showPage(0);
        });

        return allPlayers;
    }

    private void showPage(int pageIndex) {
        if (allPlayers == null || allPlayers.isEmpty()) {
            tvNoResult.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);

            tvPage.setText("0 / 0");
            btnPrev.setEnabled(false);
            btnNext.setEnabled(false);
            return;
        }
        currentPage = Math.max(0, Math.min(pageIndex, totalPages - 1));
        int from = currentPage * PAGE_SIZE;
        int to = Math.min(from + PAGE_SIZE, allPlayers.size());
        currentPagePlayers.clear();
        currentPagePlayers.addAll(allPlayers.subList(from, to));
        adapter.notifyDataSetChanged();
        tvPage.setText((currentPage + 1) + " / " + totalPages);
        btnPrev.setEnabled(currentPage > 0);
        btnNext.setEnabled(currentPage < totalPages - 1);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}