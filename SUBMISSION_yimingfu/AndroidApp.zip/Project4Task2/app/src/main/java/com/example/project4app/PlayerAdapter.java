package com.example.project4app;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;

import java.util.List;

public class PlayerAdapter extends RecyclerView.Adapter<PlayerAdapter.PlayerViewHolder> {

    List<Player> players;

    public PlayerAdapter(List<Player> players) { this.players = players; }

    public void updateData(List<Player> newList) {
        this.players.clear();
        this.players.addAll(newList);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public PlayerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.player_item, parent, false);
        return new PlayerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PlayerViewHolder holder, int position) {
        Player p = players.get(position);
        holder.tvName.setText(p.firstName + " " + p.lastName);
        holder.tvTeam.setText(p.team.fullName);
        Glide.with(holder.itemView.getContext())
                .load(p.imageUrl)               // <-- 动态 URL
                .placeholder(R.mipmap.ic_launcher)   // 加载中显示的占位图
                .error(R.mipmap.ic_launcher)         // 加载失败显示的图
                .circleCrop()                        // 可选，让头像变圆
                .into(holder.imgPlayer);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), PlayerDetailActivity.class);
            intent.putExtra("playerJson", new Gson().toJson(p));
            v.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() { return players.size(); }

    static class PlayerViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvTeam;
        ImageView imgPlayer;

        PlayerViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvPlayerName);
            tvTeam = itemView.findViewById(R.id.tvPlayerTeam);
            imgPlayer = itemView.findViewById(R.id.imgPlayer);
        }
    }
}
