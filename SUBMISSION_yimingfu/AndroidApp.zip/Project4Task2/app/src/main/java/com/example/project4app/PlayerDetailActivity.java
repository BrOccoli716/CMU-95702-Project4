package com.example.project4app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;

public class PlayerDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_detail);

        // 显示系统返回箭头
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        Button btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        String json = getIntent().getStringExtra("playerJson");
        Player p = new Gson().fromJson(json, Player.class);

        ((TextView)findViewById(R.id.tvDetailName))
                .setText(p.firstName + " " + p.lastName);
        ((TextView)findViewById(R.id.tvDetailTeam))
                .setText("Team: " + p.team.fullName);
        ((TextView)findViewById(R.id.tvDetailPosition))
                .setText(p.position);
        ((TextView)findViewById(R.id.tvDetailJerseyNumber))
                .setText(p.jerseyNumber);
        ((TextView)findViewById(R.id.tvDetailHeight))
                .setText(p.height);
        ((TextView)findViewById(R.id.tvDetailWeight))
                .setText(p.weight);
        ((TextView)findViewById(R.id.tvDetailCollege))
                .setText(p.college);
        ((TextView)findViewById(R.id.tvDetailCountry))
                .setText(p.country);
        ((TextView)findViewById(R.id.tvDetailDraftYear))
                .setText(String.valueOf(p.draftYear == 0 ? "Unknown" : p.draftYear));
        ((TextView)findViewById(R.id.tvDetailDraftRound))
                .setText(String.valueOf(p.draftRound == 0 ? "Unknown" : p.draftRound));
        ((TextView)findViewById(R.id.tvDetailDraftNumber))
                .setText(String.valueOf(p.draftNumber == 0 ? "Unknown" : p.draftNumber));

        ImageView img = findViewById(R.id.imgDetail);
        Glide.with(this).load(p.imageUrl).into(img);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();   // 返回上一页
        return true;
    }

    private String convertHeight(String height) {
        String[] parts = height.split("-");
        if (parts.length != 2) return "Unknown";
        int feet = Integer.parseInt(parts[0]);
        int inches = Integer.parseInt(parts[1]);
        double cm = feet * 30.48 + inches * 2.54;
        String height_cm = String.format("(%.1f cm)", cm);
        return height.replace("-", "'") + "\" " + height_cm;
    }

    private String convertWeight(String weight) {
        double lb = Double.parseDouble(weight);
        double kg = lb * 0.453592;
        String weight_kg = String.format("(%.1f kg)", kg);
        return weight + " lb " + weight_kg;
    }

}