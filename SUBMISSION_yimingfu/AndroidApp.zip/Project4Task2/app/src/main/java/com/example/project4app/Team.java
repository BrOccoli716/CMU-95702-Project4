package com.example.project4app;

public class Team {
    int id;
    String conference, division, city;
    String name, fullName, abbreviation;
    String imageUrl;
}
