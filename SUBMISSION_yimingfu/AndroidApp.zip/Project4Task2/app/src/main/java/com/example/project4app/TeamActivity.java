package com.example.project4app;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project4app.R;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class TeamActivity extends AppCompatActivity {
    private static final int PAGE_SIZE = 10;
    RecyclerView recyclerView;
    TeamAdapter adapter;

    List<Team> allTeams = new ArrayList<>();
    List<Team> currentPageTeams = new ArrayList<>();

    int currentPage = 0;
    int totalPages = 0;

    Button btnPrev, btnNext, btnSearch, btnBack;
    TextView tvPage, tvNoResult;
    EditText inputTeam;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_team);

        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        recyclerView = findViewById(R.id.teamRecycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new TeamAdapter(currentPageTeams);
        recyclerView.setAdapter(adapter);

        btnPrev = findViewById(R.id.btnPrev);
        btnNext = findViewById(R.id.btnNext);
        btnSearch = findViewById(R.id.btnSearch);
        btnBack = findViewById(R.id.btnBack);
        inputTeam = findViewById(R.id.inputTeam);
        tvPage = findViewById(R.id.tvPage);
        tvNoResult = findViewById(R.id.tvNoResult);
        progressBar = findViewById(R.id.progressBar);

        btnBack.setOnClickListener(v -> finish());

        btnSearch.setOnClickListener(v -> {
            currentPage = 0;
            String teamInfo = inputTeam.getText().toString().trim().toLowerCase();
            String urlString = buildUrl(teamInfo);
            System.out.println("Server URL: " + urlString);
            fetchTeams(urlString);
        });

        btnPrev.setOnClickListener(v -> {
            if (currentPage > 0) {
                showPage(currentPage - 1);
            } else {
                Toast.makeText(this, "Already first page", Toast.LENGTH_SHORT).show();
            }
        });

        btnNext.setOnClickListener(v -> {
            if (currentPage < totalPages - 1) {
                showPage(currentPage + 1);
            } else {
                Toast.makeText(this, "Already last page", Toast.LENGTH_SHORT).show();
            }
        });

        loadTeams("");
    }

    private void showLoading() {
        runOnUiThread(() -> progressBar.setVisibility(View.VISIBLE));
    }

    private void hideLoading() {
        runOnUiThread(() -> progressBar.setVisibility(View.GONE));
    }

    private String buildUrl(String teamInfo) {
        String urlString = "https://crispy-chainsaw-7qj54556j9wfxrv9-8080.app.github.dev/api/team";
        if (!teamInfo.isEmpty()) {
            urlString = "%s?team=%s".formatted(urlString, teamInfo);
        }
        return urlString;
    }

    private void fetchTeams(String url) {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)   // 连接服务器超时
                .readTimeout(15, TimeUnit.SECONDS)      // 读取响应超时
                .writeTimeout(15, TimeUnit.SECONDS)     // 写入请求超时
                .build();

        Request request = new Request.Builder()
                .url(url)
                .addHeader("Accept", "application/json")
                .addHeader("User-Agent", "Android")
                .build();

        runOnUiThread(this::showLoading);

        System.out.println("Start Requesting");

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                System.out.println("Call Failure!");
                e.printStackTrace();
                runOnUiThread(() -> {
                    hideLoading();
                    new AlertDialog.Builder(TeamActivity.this)
                            .setTitle("Error")
                            .setMessage("Request Failed!")
                            .setPositiveButton("OK", null)
                            .setCancelable(true)
                            .show();
                    showPage(0);
                    adapter.updateData(allTeams);
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                int httpStatus = response.code();
                String body = response.body().string();
                Log.d("BODY", body);
                Gson gson = new Gson();
                JsonObject root;
                try {
                    root = gson.fromJson(body, JsonObject.class);
                } catch (JsonSyntaxException e) {
                    System.out.println("Error in JSON response!");
                    runOnUiThread(() -> {
                        hideLoading();
                        new AlertDialog.Builder(TeamActivity.this)
                                .setTitle("Error")
                                .setMessage("Server Response Error!")
                                .setPositiveButton("OK", null)
                                .setCancelable(true)
                                .show();
                    });
                    return;
                }

                if (httpStatus != 200) {
                    String msg = root.has("error")
                            ? root.get("error").getAsString()
                            : "Server error: " + httpStatus;
                    System.out.println(msg);
                    runOnUiThread(() -> {
                        hideLoading();
                        runOnUiThread(() -> {
                            new AlertDialog.Builder(TeamActivity.this)
                                    .setTitle("Error")
                                    .setMessage(msg)
                                    .setPositiveButton("OK", null)
                                    .setCancelable(true)
                                    .show();
                        });
                    });
                    return;
                }
                JsonArray dataArray = root.getAsJsonArray("data");
                Log.d("TEAM_JSON", dataArray.toString());
                // TODO：解析 JSON → List<Team>
                allTeams = gson.fromJson(
                        dataArray,
                        new TypeToken<List<Team>>(){}.getType()
                );
                totalPages = (allTeams.size() + PAGE_SIZE - 1) / PAGE_SIZE;
                runOnUiThread(() -> {
                    hideLoading();
                    adapter.updateData(allTeams);
                    showPage(0);
                });
            }
        });
    }

    // NOTE: This method is only used for initializing now (default page)
    private List<Team> loadTeams(String json) {
        if (json.isEmpty()) {
            return null;
        }

        try {
            Type listType = new TypeToken<List<Team>>(){}.getType();
            allTeams = new Gson().fromJson(json, listType);
        } catch (Exception e) {
            System.out.println("Error in JSON response");
            System.out.println(e.getMessage());
        }

        totalPages = (allTeams.size() + PAGE_SIZE - 1) / PAGE_SIZE;

        runOnUiThread(() -> {
            showPage(0);
        });

        return allTeams;
    }

    private void showPage(int pageIndex) {
        if (allTeams == null || allTeams.isEmpty()) {
            tvNoResult.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);

            tvPage.setText("0 / 0");
            btnPrev.setEnabled(false);
            btnNext.setEnabled(false);
            return;
        }
        currentPage = Math.max(0, Math.min(pageIndex, totalPages - 1));
        int from = currentPage * PAGE_SIZE;
        int to = Math.min(from + PAGE_SIZE, allTeams.size());
        currentPageTeams.clear();
        currentPageTeams.addAll(allTeams.subList(from, to));
        adapter.notifyDataSetChanged();
        tvPage.setText((currentPage + 1) + " / " + totalPages);
        btnPrev.setEnabled(currentPage > 0);
        btnNext.setEnabled(currentPage < totalPages - 1);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}