package com.example.project4app;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;

import java.util.List;

public class TeamAdapter extends RecyclerView.Adapter<TeamAdapter.TeamViewHolder> {
    List<Team> teams;

    public TeamAdapter(List<Team> teams) { this.teams = teams; }

    public void updateData(List<Team> newList) {
        this.teams.clear();
        this.teams.addAll(newList);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TeamAdapter.TeamViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.team_item, parent, false);
        return new TeamAdapter.TeamViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TeamAdapter.TeamViewHolder holder, int position) {
        Team t = teams.get(position);
        holder.tvName.setText(t.fullName);
        holder.tvCity.setText(t.city);
        Glide.with(holder.itemView.getContext())
                .load(t.imageUrl)               // <-- 动态 URL
                .placeholder(R.mipmap.ic_launcher)   // 加载中显示的占位图
                .error(R.mipmap.ic_launcher)         // 加载失败显示的图
                .circleCrop()                        // 可选，让头像变圆
                .into(holder.imgTeam);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), TeamDetailActivity.class);
            intent.putExtra("teamJson", new Gson().toJson(t));
            v.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() { return teams.size(); }

    static class TeamViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvCity;
        ImageView imgTeam;

        TeamViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvTeamName);
            tvCity = itemView.findViewById(R.id.tvTeamCity);
            imgTeam = itemView.findViewById(R.id.imgTeam);
        }
    }
}
