package com.example.project4app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;

public class TeamDetailActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_team_detail);

        // 显示系统返回箭头
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        Button btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        String json = getIntent().getStringExtra("teamJson");
        Team t = new Gson().fromJson(json, Team.class);

        ((TextView)findViewById(R.id.tvDetailFullName))
                .setText(t.fullName);
        ((TextView)findViewById(R.id.tvDetailName))
                .setText(t.name);
        ((TextView)findViewById(R.id.tvDetailAbbreviation))
                .setText(t.abbreviation);
        ((TextView)findViewById(R.id.tvDetailCity))
                .setText(t.city);
        ((TextView)findViewById(R.id.tvDetailDivision))
                .setText(t.division);
        ((TextView)findViewById(R.id.tvDetailConference))
                .setText(t.conference);

        ImageView img = findViewById(R.id.imgDetail);
        Glide.with(this).load(t.imageUrl).into(img);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();   // 返回上一页
        return true;
    }
}
